# abyss-future-portfolio-ui Skill

这是“陈默 · 深海未来感个人主页”的 Codex Skill 包。

## 解压位置

请把压缩包解压到项目根目录：

```txt
D:\abyss-future-portfolio-ui\abyss-future-portfolio-ui
```

最终结构应为：

```txt
D:\abyss-future-portfolio-ui\abyss-future-portfolio-ui\.agents\skills\abyss-future-portfolio-ui\SKILL.md
```

## 参考文件要求

请把视频和 6 张设计图放到：

```txt
references/video/reference.mp4
references/design/01_home.png
references/design/02_about.png
references/design/03_skills.png
references/design/04_projects.png
references/design/05_notes.png
references/design/06_contact.png
```

## 给 Codex 的启动语句

```txt
Use the abyss-future-portfolio-ui skill.

Read the skill first. Then inspect references/video/reference.mp4 and all six images under references/design/.

Implement the complete Chenmo Abyss Personal Interface website according to the six finalized UI design images. Do not freely redesign. Do not create SaaS, product launch, dashboard, normal blog, or generic AI homepage style.
```
