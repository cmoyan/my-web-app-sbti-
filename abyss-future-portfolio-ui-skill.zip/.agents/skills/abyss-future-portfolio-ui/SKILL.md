---
name: abyss-future-portfolio-ui
description: Build Chenmo's futuristic personal introduction website using the provided underwater purple cinematic reference video and finalized UI design images. Use this skill whenever the task is about implementing, repairing, or polishing the Chenmo Abyss Personal Interface website.
---

# Skill: abyss-future-portfolio-ui

## Role

You are a senior frontend architect, high-end UI engineer, motion designer, and visual implementation specialist.

Your job is not to freely redesign the website.

Your job is to implement the finalized UI design as accurately as possible in code.

The project is a futuristic personal introduction website for “陈默”.

Correct concept:

CHENMO · Abyss Personal Interface  
陈默 · 深海未来感个人主页

## Main Objective

Build a high-end personal website that introduces 陈默.

The website content is personal:

- Who I am
- What I do
- My abilities
- My projects
- My notes / thoughts
- My contact information

The visual direction must follow:

1. The uploaded reference video.
2. The six finalized UI design images.

The website must look like a deep-sea futuristic digital personal interface.

It must not look like a generic AI SaaS homepage, product launch page, dashboard, investment portfolio website, or normal blog template.

## Reference Files

The project should contain these files:

Reference video:

```txt
references/video/reference.mp4
```

Finalized UI design images:

```txt
references/design/01_home.png
references/design/02_about.png
references/design/03_skills.png
references/design/04_projects.png
references/design/05_notes.png
references/design/06_contact.png
```

Before implementing or modifying UI, inspect these references first.

If a required reference is missing, stop and report the exact missing file path.

Do not guess the design direction.

## Visual Target

The visual language must be:

- Dark deep-sea environment
- Black-purple / deep violet background
- Pink-purple underwater lighting
- Magenta glow
- Soft water-surface light beams
- Floating particles and bubbles
- Deep seabed / reef / coral silhouettes
- Glassmorphism navigation and panels
- Large minimal Chinese typography
- Premium personal identity core
- Cinematic full-screen composition
- High-end futuristic mood
- Slow, elegant motion

The final site should feel like entering a personal digital space under the sea.

## Strict Prohibited Directions

Never create these directions:

- SaaS landing page
- Product launch page
- Product sales page
- Dashboard / admin UI
- Investment portfolio website
- Normal blog template
- Generic AI homepage
- Blue / cyan tech website
- Cheap cyberpunk neon page
- Cartoon UI
- Flat template portfolio

Never use these wrong concepts:

- “未来投资组合”
- “产品发布”
- “发射系统”
- “胶囊产品”
- “商品展示”
- “销售转化”

This is a personal introduction website, not a product website.

## Design Image Mapping

Each page must map to the finalized UI images.

### 01 Home

Reference:

```txt
references/design/01_home.png
```

Purpose:

Introduce 陈默 and establish the deep-sea futuristic personal identity.

Required elements:

- Full-screen underwater scene
- Large title “陈默”
- Label “PERSONAL DIGITAL INTERFACE”
- Subtitle: 一个从深海光影中浮现的个人数字界面。
- Description about AI product thinking, interface design, mobile experience, projects, and future systems
- Two CTA buttons: 了解我 / 查看项目
- Left text block
- Right glowing identity core
- Glass top navigation
- Bottom status cards
- Scroll indicator
- Deep violet / pink-magenta lighting

### 02 About

Reference:

```txt
references/design/02_about.png
```

Purpose:

Introduce who 陈默 is.

Required elements:

- Title: 关于我
- English subtitle: ABOUT ME
- Left-side personal introduction text
- Right-side glass identity card
- Bottom statistic cards
- Background remains underwater and cinematic
- No dense resume layout

Suggested content:

```txt
我是陈默，一个正在构建个人数字空间的人。
我关注 AI 产品、移动端体验、界面设计、项目架构和未来系统的演进方式。
这个网站不是简历模板，而是我记录想法、作品和成长的深海界面。
```

Identity card items:

- 角色：AI 产品探索者 & 界面设计师
- 专注：AI 产品 · 移动体验 · 界面设计 · 项目实践
- 信念：用设计和代码，探索未来系统的更多可能
- 位置：深海宇宙 · 数字空间
- 时间：持续进化中...

Stats:

- 4+ 项目实践
- 3+ 产品探索
- ∞ 持续学习
- 探索中 未来系统

### 03 Skills

Reference:

```txt
references/design/03_skills.png
```

Purpose:

Show personal abilities as an underwater ability system.

Required elements:

- Title: 能力系统
- English subtitle: SKILLS SYSTEM
- Left description
- Central identity core
- Orbit-style ability nodes
- Purple glowing lines connecting nodes
- No progress bars
- No normal icon grid

Skills:

- UI 设计：界面与视觉设计
- 前端开发：构建交互体验
- 移动端体验：关注用户触点
- 项目架构：设计系统结构
- Codex 工作流：AI 辅助开发
- 自动化系统：提效探索

### 04 Projects

Reference:

```txt
references/design/04_projects.png
```

Purpose:

Show personal projects as deep-sea glass cards.

Required elements:

- Title: 项目实践
- English subtitle: PROJECTS
- Category pills
- Four project cards
- Each card has image area, title, tags, description, and “查看详情”
- Background underwater lighting remains visible
- No pricing cards
- No product sales tone

Projects:

1. 昔年 Aura  
   Tags: AI 产品 / 系统工具  
   Description: 私人 AI 系统与 API 中转站实验，包含用户端、管理后台和安全验证体系。

2. GoTrip  
   Tags: 移动应用 / UI/UX  
   Description: 面向移动端的出行规划 App UI 实践，关注路线、预算、社区和体验设计。

3. API 中转站  
   Tags: AI 产品 / 系统工具  
   Description: 面向模型调用、密钥、Key 管理和用户系统的产品化实践。

4. 个人网站系统  
   Tags: 系统工具 / 设计实验  
   Description: 一个用于承载个人介绍、项目展示和思考记录的未来感数字界面。

### 05 Notes

Reference:

```txt
references/design/05_notes.png
```

Purpose:

Show thoughts and notes as futuristic archive entries.

Required elements:

- Title: 思考记录
- English subtitle: NOTES
- Left intro text
- Category pills
- Two-column note archive list
- Each note item has thumbnail, title, date, and short description
- No normal blog list

Notes:

- AI 产品思考
- UI 设计复盘
- 项目开发记录
- 个人成长笔记
- Codex 工作流记录
- 未来系统观察

### 06 Contact

Reference:

```txt
references/design/06_contact.png
```

Purpose:

End with a personal contact portal.

Required elements:

- Title: 联系我
- English subtitle: CONTACT
- Left contact text
- Contact glass card
- Large glowing underwater portal on the right
- Social icons
- Footer
- Back-to-top button
- No sales CTA

Contact content:

```txt
如果你想了解我的项目、设计或想法，可以从这里联系我。
```

Contact items:

- 发送邮件
- 查看 GitHub
- 关注我

## Color System

Use this strict palette:

```css
--abyss-black: #05020A;
--deep-violet: #12051F;
--ocean-purple: #26103D;
--midnight-blue: #070B1F;
--rose-fog: #FF7ABF;
--magenta-glow: #D946EF;
--violet-glow: #8B5CF6;
--soft-purple: #A78BFA;
--warm-sand: #C28A5C;
--pearl-white: #FFF7FB;
--mist-text: rgba(255, 247, 251, 0.74);
--glass-bg: rgba(255, 255, 255, 0.07);
--glass-border: rgba(255, 255, 255, 0.16);
```

Cyan / teal is not allowed as the main visual identity.

Cyan can only be used as a tiny secondary highlight if absolutely necessary.

## Typography

Chinese:

- Prefer PingFang SC, HarmonyOS Sans, Microsoft YaHei, Noto Sans SC
- Large Chinese titles must be bold, clean, and cinematic
- Avoid playful fonts
- Avoid template-looking typography

English:

- Inter, Space Grotesk, Satoshi, or system sans-serif
- Use uppercase labels with letter spacing

Typography style:

- Large title
- Short subtitle
- Minimal paragraph text
- Plenty of spacing
- No dense text blocks

## Layout Rules

Desktop:

- Each section should feel like a cinematic screen.
- Use full-screen or near full-screen sections.
- Keep the navigation consistent across sections.
- Use left text + right visual/card layout where appropriate.
- Use large spacing and strong hierarchy.
- Background should remain immersive.
- Avoid white blocks and generic layout.

Mobile:

- Do not simply shrink desktop.
- Stack content vertically.
- Keep large readable titles.
- Simplify visual layers.
- Reduce particles and heavy effects.
- Use touch-friendly buttons.
- Keep navigation compact.
- Avoid hover-only interactions.

## Motion Rules

Motion must be premium and slow.

Allowed:

- Slow floating
- Soft glow pulse
- Particle drift
- Light beam movement
- Scroll reveal
- Glass panel fade-in
- Gentle parallax

Forbidden:

- Fast bouncing
- Cartoon motion
- Random spinning
- Excessive animations
- Overloaded motion on mobile

Respect prefers-reduced-motion.

## Technical Stack

Use the existing project stack.

Preferred:

- Next.js
- React
- TypeScript
- Tailwind CSS or CSS Modules
- Framer Motion if needed
- Three.js / React Three Fiber only if stable
- GSAP / Lenis only if necessary

Do not add unnecessary dependencies.

Do not add backend, login, database, CMS, comments, admin pages, or payment features.

## Next.js Rules

Any component using these must be a client component with `"use client";`:

- React hooks
- useEffect
- useState
- window
- document
- framer-motion
- Canvas
- Three.js
- React Three Fiber
- GSAP
- Lenis

If WebGL or Three.js causes SSR issues, load it with next/dynamic and ssr:false.

Do not leave runtime errors.

## Implementation Workflow

Before modifying code:

1. Confirm reference video exists.
2. Confirm all six UI design images exist.
3. Inspect current project files.
4. Identify the wrong UI direction if any.
5. List files that will be changed.
6. Explain the implementation plan briefly.

Implementation priority:

1. Rebuild or correct the UI according to the six reference design images.
2. Keep the visual direction close to the video.
3. Keep the content personal.
4. Preserve responsive behavior.
5. Keep the project running.

Do not freely redesign.

Do not reinterpret the concept.

Do not simplify into a generic page.

## Acceptance Criteria

The result is accepted only if:

- It is clearly a personal website for 陈默.
- It visually matches the six provided UI design images.
- It feels close to the reference video.
- It uses deep-sea purple / magenta cinematic visuals.
- It has glass navigation and panels.
- It has large minimal Chinese typography.
- It has the six sections: 首页、关于我、能力、项目、笔记、联系.
- It does not look like a SaaS website.
- It does not look like a product launch website.
- It does not look like a dashboard.
- It does not look like a generic portfolio template.
- It runs without Next.js runtime errors.
- It works on desktop and mobile.
