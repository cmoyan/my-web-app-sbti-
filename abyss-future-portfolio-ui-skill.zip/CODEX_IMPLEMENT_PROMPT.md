Use the `abyss-future-portfolio-ui` skill.

Read the skill first.

Important:
The skill and this prompt are both mandatory. If there is any conflict with older project code or old instructions, follow this prompt and the current skill.

Project path:

D:\abyss-future-portfolio-ui\abyss-future-portfolio-ui

Required skill path:

.agents/skills/abyss-future-portfolio-ui/SKILL.md

Required reference video:

references/video/reference.mp4

Required finalized UI design images:

references/design/01_home.png
references/design/02_about.png
references/design/03_skills.png
references/design/04_projects.png
references/design/05_notes.png
references/design/06_contact.png

Before coding, check whether all these files exist.

If any file is missing, stop and tell me the exact missing path.

Do not guess.

MAIN TASK:

Implement the complete “陈默 · 深海未来感个人主页” website according to the six finalized UI design images and the reference video.

This is not a free design task.

Do not create your own new style.

Recreate the provided UI design as closely as possible in code.

Correct concept:

CHENMO · Abyss Personal Interface  
陈默 · 深海未来感个人主页

Website content:

- 首页
- 关于我
- 能力系统
- 项目实践
- 思考记录
- 联系我

Visual target:

The final website must feel like the provided UI design images and the uploaded video:

- dark underwater scene
- black-purple / deep violet background
- pink-purple light beams
- magenta glow
- seabed / reef / coral atmosphere
- floating glowing identity core
- glassmorphism navigation
- glass cards and panels
- large minimal Chinese typography
- cinematic high-tech personal website

This is a personal introduction website for 陈默.

It is not:

- SaaS landing page
- product launch page
- product sales website
- dashboard
- admin system
- investment portfolio website
- normal blog template
- generic AI homepage
- blue / cyan tech page
- cheap cyberpunk page

Do not use “未来投资组合”.

Do not use product-launch wording.

Do not make it look like a sales page.

IMPLEMENTATION REQUIREMENTS:

1. Inspect the existing project.
2. Identify existing wrong UI files.
3. Replace or refactor the homepage and section components to match the finalized designs.
4. Implement all six sections in one scrollable landing website.
5. Use responsive desktop and mobile layout.
6. Keep clean component structure.
7. Do not add backend, login, database, CMS, comments, admin pages, payment, or unrelated features.
8. Keep TypeScript clean.
9. Keep the app runnable.
10. Do not leave any Next.js runtime error.

RECOMMENDED STRUCTURE:

components/
  layout/
    SiteHeader.tsx
    MobileMenu.tsx

  sections/
    HomeSection.tsx
    AboutSection.tsx
    SkillsSection.tsx
    ProjectsSection.tsx
    NotesSection.tsx
    ContactSection.tsx

  ui/
    GlassPanel.tsx
    GlowButton.tsx
    SectionLabel.tsx
    NavOrb.tsx
    StatusCard.tsx

  visuals/
    AbyssBackground.tsx
    IdentityCore.tsx
    ReefLayer.tsx
    LightBeams.tsx
    ParticleLayer.tsx

lib/
  cn.ts

app/
  page.tsx
  globals.css

You may use CSS Modules or Tailwind CSS, but the final result must match the design images visually.

SECTION DETAILS:

01 HOME must follow references/design/01_home.png

Required:

- Logo area: 陈默 / CHENMO
- Navigation: 首页 / 关于我 / 能力 / 项目 / 笔记 / 联系
- Small label: PERSONAL DIGITAL INTERFACE
- Main title: 陈默
- Subtitle: 一个从深海光影中浮现的个人数字界面。
- Description: 这里记录我的 AI 产品想法、界面设计、移动端体验、项目实践和对未来系统的思考。
- Buttons: 了解我 / 查看项目
- Right-side glowing personal identity core
- Bottom cards: 深海模式 / 系统状态 / 深度
- Scroll indicator

02 ABOUT must follow references/design/02_about.png

Required:

- Title: 关于我
- English subtitle: ABOUT ME
- Left intro text
- Right glass identity card
- Bottom statistic cards

Text:

我是陈默，一个正在构建个人数字空间的人。  
我关注 AI 产品、移动端体验、界面设计、项目架构和未来系统的演进方式。  
这个网站不是简历模板，而是我记录想法、作品和成长的深海界面。

Identity card items:

角色：AI 产品探索者 & 界面设计师  
专注：AI 产品 · 移动体验 · 界面设计 · 项目实践  
信念：用设计和代码，探索未来系统的更多可能  
位置：深海宇宙 · 数字空间  
时间：持续进化中...

Stats:

4+ 项目实践  
3+ 产品探索  
∞ 持续学习  
探索中 未来系统

03 SKILLS must follow references/design/03_skills.png

Required:

- Title: 能力系统
- English subtitle: SKILLS SYSTEM
- Left description
- Center glowing identity core
- Orbit-style ability nodes
- Purple glowing orbit lines
- No progress bars

Skills:

UI 设计：界面与视觉设计  
前端开发：构建交互体验  
移动端体验：关注用户触点  
项目架构：设计系统结构  
Codex 工作流：AI 辅助开发  
自动化系统：提效探索

04 PROJECTS must follow references/design/04_projects.png

Required:

- Title: 项目实践
- English subtitle: PROJECTS
- Category pills
- Four project cards
- Card image area
- Card title, tags, description, and action

Projects:

昔年 Aura
Tags: AI 产品 / 系统工具
Description: 私人 AI 系统与 API 中转站实验，包含用户端、管理后台和安全验证体系。

GoTrip
Tags: 移动应用 / UI/UX
Description: 面向移动端的出行规划 App UI 实践，关注路线、预算、社区和体验设计。

API 中转站
Tags: AI 产品 / 系统工具
Description: 面向模型调用、密钥、Key 管理和用户系统的产品化实践。

个人网站系统
Tags: 系统工具 / 设计实验
Description: 一个用于承载个人介绍、项目展示和思考记录的未来感数字界面。

05 NOTES must follow references/design/05_notes.png

Required:

- Title: 思考记录
- English subtitle: NOTES
- Left intro
- Category pills
- Two-column archive entries
- Thumbnail, title, date, description

Notes:

AI 产品思考
Date: 2026/06/01
Description: 关于 AI 产品方向、市场机会与用户价值的一些思考。

UI 设计复盘
Date: 2026/05/28
Description: 界面设计中的色彩、体验、信息架构及合理性。

项目开发记录
Date: 2026/05/20
Description: 记录项目开发过程中的关键节点、问题和思考解决方案。

个人成长笔记
Date: 2026/05/15
Description: 关于学习、思维、习惯和自我提升的记录。

Codex 工作流记录
Date: 2026/05/10
Description: 如何使用 Codex 提升开发效率和项目质量。

未来系统观察
Date: 2026/05/05
Description: 对未来产品、交互、AI 与新物种概念的观察与想象。

06 CONTACT must follow references/design/06_contact.png

Required:

- Title: 联系我
- English subtitle: CONTACT
- Left contact text
- Glass contact card
- Large glowing underwater portal on the right
- Social icons
- Footer
- Back-to-top button

Text:

如果你想了解我的项目、设计或想法，可以从这里联系我。

Contact items:

发送邮件：chenmo@example.com  
查看 GitHub：github.com/chenmo  
关注我：更多平台即将开放

STYLE REQUIREMENTS:

Use this palette:

--abyss-black: #05020A
--deep-violet: #12051F
--ocean-purple: #26103D
--midnight-blue: #070B1F
--rose-fog: #FF7ABF
--magenta-glow: #D946EF
--violet-glow: #8B5CF6
--soft-purple: #A78BFA
--warm-sand: #C28A5C
--pearl-white: #FFF7FB
--mist-text: rgba(255, 247, 251, 0.74)
--glass-bg: rgba(255, 255, 255, 0.07)
--glass-border: rgba(255, 255, 255, 0.16)

Cyan / teal is not allowed as the main color.

Use:

- Deep violet underwater background
- Pink-purple beams
- Magenta glow
- Glass cards
- Fine borders
- Large Chinese titles
- Soft particles
- Reef/coral silhouettes
- Strong cinematic spacing

Do not use:

- White background blocks
- SaaS blue gradients
- Dashboard chips
- Pricing cards
- Normal blog list style
- Flat icon grid
- Bright cyan identity

MOTION REQUIREMENTS:

Use slow premium motion only.

Allowed:

- soft floating
- glow pulse
- particle drift
- scroll reveal
- gentle parallax
- slow orbit line effect

Forbidden:

- cartoon bounce
- aggressive spinning
- random motion
- too many animations at once

Respect prefers-reduced-motion.

NEXT.JS RULES:

Any component using hooks, framer-motion, window, document, canvas, Three.js, GSAP, or Lenis must start with `"use client";`.

If you use WebGL or Three.js, make it client-only with dynamic import and ssr:false.

If CSS/SVG can match the design closely enough, prefer CSS/SVG first to avoid runtime errors.

Do not leave the app broken.

PROCESS:

Before editing, output a short plan:

1. Confirm reference files exist.
2. Explain what existing UI direction is wrong.
3. List files to change.
4. Explain how you will map the six design images to components.

Then implement.

After editing:

1. Run npm install if needed.
2. Run npm run dev.
3. Fix runtime errors if any.
4. Run npm run build if available.
5. Summarize changed files.
6. Explain how the result matches the video and six UI images.
7. Explain how to run locally.

Do not stop at explanation.

Actually modify the project files.

Acceptance criteria:

The final homepage must clearly look like the six reference design images, not a newly invented design.

The final site must look like:

“陈默 · 深海未来感个人主页”

It must not look like:

SaaS, product launch, dashboard, normal portfolio, investment portfolio, generic AI page, or cheap cyberpunk page.
